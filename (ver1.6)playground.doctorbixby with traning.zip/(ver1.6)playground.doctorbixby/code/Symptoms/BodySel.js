module.exports.function = function bodySel (images) {
  return images;
}
