module.exports.function = function showShell1 (upart,usymptom,diagResult) {
  return diagResult;
}
