module.exports.function = function showSymptoms (symptoms) {
  var console = require('console');
  var list = symptoms.naming.split("|");
  var str = list[1];
  return str
}
