module.exports.function = function diagnose (sympFin) {
  
  //  비즈니스팀 로직 짜주세요

  // dummy 판단 지워도 됨
  var console = require('console');
  var data = [[],[],[],[],[]];
  var dname = "백일해";
  var defin = "백일해는 보르데텔라 백일해균에 의한 감염으로 발생하는 호흡기 질환입니다.";
  var url = "http://www.samsunghospital.com/home/healthInfo/content/contenView.do?CONT_SRC_ID=09a4727a8000f243&CONT_SRC=CMS&CONT_ID=1611&CONT_CLS_CD=001020001013";
  var iurl = "http://www.samsunghospital.com/upload/smccms_export/disease/pertussis.jpg";
  data[0][0] = dname;
  data[0][1] = defin;
  data[0][2] = url;
  data[0][3] = iurl;
  dname = "장염";
  defin = "장염이란 장에 염증을 일으키는 질환을 말하며 원인은 매우 다양합니다.";
  url = "http://www.samsunghospital.com/home/healthInfo/content/contenView.do?CONT_SRC_ID=09a4727a8000f321&CONT_SRC=CMS&CONT_ID=3471&CONT_CLS_CD=001020001013";
  iurl = "http://www.samsunghospital.com/upload/smccms_export/disease/enteritis.jpg";
  data[1][0] = dname;
  data[1][1] = defin;
  data[1][2] = url;
  data[1][3] = iurl;
  dname = "녹내장";
  defin = "녹내장은 눈에서 대뇌로 시각정보를 전달하는 시신경이 손상되는 질환들 중의 하나입니다.";
  url = "http://www.samsunghospital.com/home/healthInfo/content/contenView.do?CONT_SRC_ID=09a4727a8000f1e3&CONT_SRC=CMS&CONT_ID=1031&CONT_CLS_CD=001020001002";
  iurl = "http://www.samsunghospital.com/upload/smccms_export/disease/glaucoma_suspect.jpg";
  data[2][0] = dname;
  data[2][1] = defin;
  data[2][2] = url;
  data[2][3] = iurl;
  dname = "대장용종";
  defin = "대장에 생기는 양성 종양을 용종 또는 폴립이라고 합니다.";
  url = "http://www.samsunghospital.com/home/healthInfo/content/contenView.do?CONT_SRC_ID=09a4727a8000f20a&CONT_SRC=CMS&CONT_ID=3032&CONT_CLS_CD=001020001012";
  iurl = "http://www.samsunghospital.com/upload/smccms_export/disease/polyp_of_colon.jpg";
  data[3][0] = dname;
  data[3][1] = defin;
  data[3][2] = url;
  data[3][3] = iurl;
  dname = "심낭압전";
  defin = "심장압전이란 심장을 둘러싸고 있는 막 사이에 혈액이 고여 심장을 누르게 됨으로서 심박출량이 감소하여 쇼크에 이르게 하는 병입니다.";
  url = "http://www.samsunghospital.com/home/healthInfo/content/contenView.do?CONT_SRC_ID=09a4727a8000f2a9&CONT_SRC=CMS&CONT_ID=1619&CONT_CLS_CD=001020001004";
  iurl = "http://www.samsunghospital.com/upload/smccms_export/disease/cardiac_tamponade.jpg";
  data[4][0] = dname;
  data[4][1] = defin;
  data[4][2] = url;
  data[4][3] = iurl;
  console.log(data);
  var result = [];
  for(var i=0;i<data.length;i++){
     var rs = {
       diseaseInfo : data[i]
     }
     result[i] = {
       data : rs
     }
  }
  console.log(result);
  return result;
}
