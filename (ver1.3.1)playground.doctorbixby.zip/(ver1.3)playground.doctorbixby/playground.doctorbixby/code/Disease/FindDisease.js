module.exports.function = function findDisease(dName, query) {
  var console = require('console');
  /*
  [0] 질병 분류
  [1] 내용
  [2] 질병 이름
  [3] 내용
  [4] 정의
  [5] 내용
  [6] 원인
  [7] 내용
  [8] 증상
  [9] 내용
  [10] 진단
  [11] 내용
  [12] 치료법
  [13] 내용
  [14] 질병의 진행
  [15] 내용
  [16] 합병증
  [17] 내용
  [18] 예방법
  [19] 내용
  [20] 생활습관
  [21] 내용
  [22] URL
  [23] 내용
  [24] IMG URL
  [25] 내용
  // 더미데이터
  //var result = [];
  //var flag = [];
  result.push("질병 분류")
  flag.push(0);
  result.push("감염성 질환");
  flag.push(1);
  result.push("질병 이름")
  flag.push(0);
  result.push("간디스토마");
  flag.push(1);
  result.push("정의")
  flag.push(0);
  result.push("간디스토마는 식품을 매개로 감염되는 기생충질환으로 간흡충이 우리 몸에 들어와 간의 담관 안에서 기생하면서 여러 가지 증상을 일으키는 병입니다.");
  flag.push(1);
  result.push("원인")
  flag.push(0);
  result.push("간흡충에 감염되어 나타납니다. 간흡충에 감염된 사람 또는 야생동물의 대변을 통하여 알이 배출되고, 이 알은 제 1중간숙주인 민물 조개류에게 먹혀 유충으로 자라게 됩니다. 이 유충은 중간숙주에서 나와 제 2중간숙주인 민물고기에 침입하여 피낭유충이 됩니다. 이 때, 사람이 피낭유충이 들어있는 민물고기를 날것으로 먹었을 때, 또는 이로인해 오염된 칼, 도마 등을 통하여 간흡충에 감염됩니다. 인체에 들어온 간흡충은 간이나 담관, 그리고 담낭 속에서 기생하면서 여러가지 증상을 일으킵니다.");
  flag.push(1);
  result.push("증상")
  flag.push(0);
  result.push("증상은 감염 기생충 수, 감염 기간, 합병증에 따라 다양하게 나타납니다. 감염 정도가 심하지 않으면 증상이 거의 나타나지 않아 대부분 증상을 모르고 지냅니다. 그러나 감염 기생충 수가 많거나 감염기간이 길어지게 되면 여러가지 증상이 나타나게 됩니다. 급성감염 시에는 상복부통증, 발열, 소화불량, 위장출혈, 설사 등의 소화기 장애가 나타나는데 심하면 사망에 이를 수 있습니다. 상태가 점점 악화되면 황달, 간 비대, 복수 등의 증상이 나타납니다. 간흡충이 담관에 물리적, 화학적 자극을 가하고 여기에 이차적인 세균침입으로 인해 염증을 일으켜 담관염이나 담낭염이 발생하여 열이나고 복통이 나타날 수 있습니다. 또한 많은 수의 간흡충이 담관에 감염될 경우 담도폐쇄를 일으키고 이로인해 담석이 생길 수 있습니다. 이러한 증상이 지속되면 담관암이 생길 수도 있으며 간암을 유발하기도 합니다.");
  flag.push(1);
  result.push("진단")
  flag.push(0);
  result.push("일반적으로 대변충란 검사법으로 대변에서 간흡충의 알을 확인하여 진단합니다. 대변 내 알의 수를 측정하여 감염 정도를 추정할 수 있습니다. 혈액 검사를 통하여 간흡충증에 대한 항체여부를 확인하여 진단에 보조적인 정보를 제공합니다. 복부초음파나 컴퓨터단층촬영(CT)으로 담관 내의 간흡충의 기생여부를 알 수 있고, 담낭, 담관의 염증, 결석, 담관암 등의 이차적인 합병증을 관찰할 수 있습니다.");
  flag.push(1);
  result.push("치료법")
  flag.push(0);
  result.push("구충제인 프라지콴텔(praziquantel)을 1일 3회 하루만 먹으면 대부분 치료가 됩니다. 하루 먹었을 때 치료가 안되었을 경우 같은 용법으로 반복하여 먹습니다.");
  flag.push(1);
  result.push("질병의 진행")
  flag.push(0);
  result.push("구충제를 복용하고 2~3주 후에 대변검사를 하여 완치여부를 확인하고, 완치가 되었다면 1년 후 다시 검사를 시행합니다. 감염이 오랫동안 지속되어 증상이 악화되면 담낭염, 담관염, 담석, 담관암 등의 합병증이 발생할 수 있습니다.");
  flag.push(1);
  result.push("합병증")
  flag.push(0);
  result.push("없음");
  flag.push(0);
  result.push("예방법")
  flag.push(0);
  result.push("예방을 위해서는 민물고기를 날것으로 먹지 않고 완전히 익혀먹는 것이 좋습니다. 민물고기를 다루는데 사용한 칼과 도마 등의 주방 용품은 반드시 끓는 물에 10초 이상 담궈서 소독하여 사용하도록 합니다.");
  flag.push(1);
  result.push("생활 습관")
  flag.push(0);
  result.push("없음");
  flag.push(0);
  result.push("상세정보 보기")
  flag.push(0);
  result.push("http://www.samsunghospital.com/home/healthInfo/content/contenView.do?CONT_SRC_ID=09a4727a8000f196&CONT_SRC=CMS&CONT_ID=3515&CONT_CLS_CD=001020001013");
  flag.push(1);
  result.push("IMG URL")
  flag.push(0);
  result.push("http://www.samsunghospital.com/upload/smccms_export/disease/clonorchisis_sinensis.jpg");
  flag.push(1);
  */
  // 세미 여기 논리 작성해줘

  var result = "http://www.samsunghospital.com/home/healthInfo/content/contenView.do?CONT_SRC_ID=09a4727a8000f196&CONT_SRC=CMS&CONT_ID=3515&CONT_CLS_CD=001020001013";
  return {
    data : result,
    //flag : flag
  }
}
