module.exports.function = function teethSel (images) {
  return images;
}
