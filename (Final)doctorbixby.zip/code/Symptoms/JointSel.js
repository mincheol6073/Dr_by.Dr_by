module.exports.function = function jointSel (images) {
  return images;
}
