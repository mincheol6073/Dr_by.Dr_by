module.exports.function = function selParts (images) {
  var console = require('console');
   var str = "";
   var cnt = images.length;
   for(var i = 0; i<images.length;i++){
     str += images[i].naming;
     if(i<images.length-1) str += "/";
   }
   var parts = str.split("/");
   var nums = [];
   for(var i=0;i<parts.length;i++){
     switch(parts[i]) {
      case "귀" : nums[i] = 1;
                   break;
      case "입" : nums[i] = 2;
                   break;
      case "눈" : nums[i] = 3;
                   break;
      case "엉덩이" : nums[i] = 4;
                   break;
      case "무릎" : nums[i] = 5;
                   break;
      case "폐" : nums[i] = 6;
                   break;
      case "손" : nums[i] = 7;
                   break;
      case "갈비뼈" : nums[i] = 8;
                   break;
      case "코" : nums[i] = 9;
                   break;
      case "팔" : nums[i] = 10;
                   break;
      case "허벅지" : nums[i] = 11;
                   break;
      case "발" : nums[i] = 12;
                   break;
      case "신장" : nums[i] = 13;
                   break;
      case "관절" : nums[i] = 14;
                   break;
      case "피부" : nums[i] = 15;
                   break;
      case "다리" : nums[i] = 16;
                   break;
      case "방광" : nums[i] = 17;
                   break;
      case "얼굴" : nums[i] = 18;
                   break;
      case "가슴" : nums[i] = 19;
                   break;
      case "심장" : nums[i] = 20;
                   break;
      case "머리" : nums[i] = 21;
                   break;
      case "목" : nums[i] = 22;
                   break;
      case "어깨" : nums[i] = 23;
                   break;
      case "상처" : nums[i] = 24;
                   break;
      case "배" : nums[i] = 25;
                   break;
      case "등" : nums[i] = 26;
                   break;
      case "정신" : nums[i] = 27;
                   break;
      case "치아" : nums[i] = 28;
                   break;
      case "신경계" : nums[i] = 29;
                   break;
      case "남성 생식기" : nums[i] = 31;
                   break;
      case "손톱" : nums[i] = 32;
                   break;
      case "여성 생식기" : nums[i] = 33;
                   break;
      case "생식기" : nums[i] = 34;
                   break;
      case "쓸개" : nums[i] = 35;
                   break;

      case "허리" : nums[i] = 36;
                   break;
     }
   }
   console.log(nums);
   str += "|";
   console.log(str);
  return{
    naming : str,
    count : cnt,
    partnum : nums
  }
}
