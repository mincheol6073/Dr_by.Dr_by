module.exports.function = function detailHS (hsData) {
  var console = require('console');
  console.log(hsData.location[1].latitude);
  console.log(hsData.location[1].longitude);
  var tmp = [hsData.location[1].latitude,hsData.location[1].longitude];
  var resultData = {
    location : hsData.location,
    info : hsData.info,
    distance : hsData.distance,
    pointmap : tmp
  }
  return resultData;
}
