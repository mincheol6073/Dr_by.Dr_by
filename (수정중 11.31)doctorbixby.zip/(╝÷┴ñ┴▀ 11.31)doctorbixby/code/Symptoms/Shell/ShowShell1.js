module.exports.function = function showShell1 (home, upart,usymptom,diagResult) {
  return diagResult;
}
