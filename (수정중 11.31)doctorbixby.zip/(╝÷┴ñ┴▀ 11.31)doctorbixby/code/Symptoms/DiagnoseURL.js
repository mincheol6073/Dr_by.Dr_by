module.exports.function = function diagnoseURL (url) {
  var console = require('console');
  console.log(url);
  return url;
}
