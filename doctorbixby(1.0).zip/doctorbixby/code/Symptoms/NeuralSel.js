module.exports.function = function neuralSel (images) {
  return images;
}
