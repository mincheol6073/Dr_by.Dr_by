module.exports.function = function stomachSel (images) {
  return images;
}
