module.exports.function = function earSel (images) {
  return images;
}
