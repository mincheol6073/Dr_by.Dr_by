module.exports.function = function mouthSel (images) {
  return images;
}
