module.exports.function = function findDisease(dName, query) {
  var console = require('console');
  var Data = require("data/Data.js");
  var result;
  for (var k = 0; k < Data.length; k++) { // 만약 data의 size가 주어질 수 있을듯? (유지보수 관점에서 json 파일의 형태를 어떻게 저장?)
   var disease = Data[k];
   if(disease.disease_name_kr == dName){
     result = [disease.detail_url,dName];
     break;
   }
  }
  return {
    data : result
  }
}
