module.exports.function = function headSel (images) {
  return images;
}
