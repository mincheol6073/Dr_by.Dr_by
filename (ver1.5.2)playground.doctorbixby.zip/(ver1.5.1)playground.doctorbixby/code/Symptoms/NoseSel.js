module.exports.function = function noseSel (images) {
  return images;
}
