module.exports.function = function findHospital(point, home, department, find) {
  const config = require('config');
  const http = require('http');
  const fail = require('fail');
  const kakaoLocalAPI = config.get('kakaoLocalAPIURL');
  const APIKey = config.get('kakaoAPIKey');
  var console = require('console');

  let api_key = APIKey;
  let url = kakaoLocalAPI;
  console.debug(api_key);
  console.debug(url);
  console.debug(point.latitude);
  console.debug(point.longitude);
  console.debug(department);

  var options = {
    format: 'json',
    headers: {
      'Authorization': api_key
    },
    query: {
      query: department,
      x: point.longitude,
      y: point.latitude,
      radius: 5000,
      sort: 'distance',
    }
  }

  let response = http.getUrl(url, options);

  if (response.status == 404 || response.status == 500 || response.status == 502 || response.status == 504) {
    throw fail.checkedError("Server Error", "ServerProblem");
  }
  let datas = response.documents;
  var results = [];

  for (var i = 0; i < datas.length; i++) {
    var latitude = datas[i].y;
    var longitude = datas[i].x;
    var place_name = datas[i].place_name;
    var address_name = datas[i].address_name;
    var phone = datas[i].phone;
    var distance = datas[i].distance;
    if (place_name && address_name && phone) {
      results[i] = {
        data: {
          location: [{ latitude: point.latitude, longitude: point.longitude }, { latitude: parseFloat(latitude), longitude: parseFloat(longitude) }],
          info: [place_name, address_name, phone, department[0]],
          distance: parseInt(distance)
        }
      }
    }
  }

  return results;
}