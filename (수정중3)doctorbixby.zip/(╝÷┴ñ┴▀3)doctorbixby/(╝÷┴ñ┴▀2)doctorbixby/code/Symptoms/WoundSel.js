module.exports.function = function woundSel (images) {
  return images;
}
