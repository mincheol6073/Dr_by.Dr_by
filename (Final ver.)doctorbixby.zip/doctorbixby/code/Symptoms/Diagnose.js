module.exports.function = function diagnose(sympFin) {
 var console = require('console');
 // 윤형아 로직 짜줘
 var Data = require("data/Data.js");
 //var symp = "몸:발열/몸:피로감/머리:현기증/"
 var symptomArray = sympFin.split("/"); // 증상 split
 var resultArray = new Array();
 var keywordArray = new Array();
 var result_cnt = 0;
 var min_match = -1;
 var min_idx = -1;
 for (var k = 0; k < Data.length; k++) { // 만약 data의 size가 주어질 수 있을듯? (유지보수 관점에서 json 파일의 형태를 어떻게 저장?)
   var count = 0;
   var disease = Data[k];
   var keywords = JSON.stringify(disease.keyword).split("],");
    // console.log(keywords);  

   for (var u = 0; u < keywords.length; u++) {
     keywordArray[u] = keywords[u].split(":");
   }
   for (var j = 0; j < symptomArray.length; j++) {
     var symptom = symptomArray[j].split(":");
     for (var u = 0; u < keywords.length; u++) {
       var key1 = "" + JSON.stringify(keywordArray[u][0]);
       var key2 = "" + JSON.stringify(keywordArray[u][1]);
       if (key1.includes(symptom[0]) && key2.includes(symptom[1])) {
         count++;
         break;
       }
     }
   }
   if(result_cnt < 5){
     resultArray.push([disease.disease_name_kr, disease.definition, disease.detail_url, 
   disease.img_url, count / (symptomArray.length-1)]);
     result_cnt++;
     if(result_cnt == 5){
       min_match = Math.min(resultArray[0][4],resultArray[1][4],resultArray[2][4],resultArray[3][4],resultArray[4][4]);
       for(var z=0;z<resultArray.length;z++){
         if(resultArray[z][4] == min_match){
           min_idx = z;
           break;
         }
       }
     }
   }
   if(result_cnt == 5){
     if((count / (symptomArray.length-1)) > min_match){
       resultArray[min_idx] = [disease.disease_name_kr, disease.definition, disease.detail_url, 
   disease.img_url, count / (symptomArray.length-1)];
       min_match = Math.min(resultArray[0][4],resultArray[1][4],resultArray[2][4],resultArray[3][4],resultArray[4][4]);
       for(var z=0;z<resultArray.length;z++){
         if(resultArray[z][4] == min_match){
           min_idx = z;
           break;
         }
       }
      console.log(resultArray);
     }
   }
 }
 console.log(resultArray);
 resultArray.sort(function(a,b){
   return a[4]-b[4];
 });
 // 결과 담기. 수정 X
 var result = [];
 var idx = 0;
 while(idx < 5) {
   var tmp = resultArray.pop();
   var rs = {
     diseaseInfo: tmp
   }
   result[idx] = {
     data: rs
   }
   idx++;
 }
 return result;
}