module.exports.function = function chestSel (images) {
  return images;
}
