module.exports.function = function selectAll (symptoms, images) {
  var console = require('console');
  var str = symptoms.naming;
  for(var i = 0; i<images.length;i++){
        str += "몸";
        str += ":"
        str += images[i].naming;
        str += "/";
   } 
  return{
    naming : str,
    count : symptoms.count,
    partnum : symptoms.partnum
  }
}