module.exports.function = function diagnose(sympFin) {
 var console = require('console');
 var Data = require("./data/Data.js");
 var symp = "몸:발열/몸:피로감/머리:현기증/"
 var symptomArray = symp.split("/"); // 증상 split
 var resultArray = new Array();
 var keywordArray = new Array();
 for (var k = 0; k < Data.length; k++) { // 만약 data의 size가 주어질 수 있을듯? (유지보수 관점에서 json 파일의 형태를 어떻게 저장?)
   var count = 0;
   var disease = Data[k];
   var keywords = JSON.stringify(disease.keyword).split("\",\"");
 
   for (var u = 0; u < keywords.length; u++) {
     keywordArray[u] = keywords[u].split(":");
   }
   for (var j = 0; j < symptomArray.length; j++) {
     var symptom = symptomArray[j].split(":");
     for (var u = 0; u < keywords.length; u++) {
       if (keywordArray[u][0].includes(symptom[0]) && keywordArray[u][1].includes(symptom[1])) {
         count++;
         break;
       }
     }
   }
   resultArray.push([disease.disease_name_kr, disease.definition, disease.detail_url, disease.img_url, count / (symptomArray.length-1)]);
 }
 resultArray.sort(function(a,b){
   return a[4]-b[4];
 });
 var data = [[], [], []];
 for(var num = 0; num < 3; num++){
   var tempresult =resultArray.pop();
 data[num][0] = tempresult[0];
 data[num][1] = tempresult[1];
 data[num][2] = tempresult[2];
 data[num][3] = tempresult[3];
}
 var result = [];
 for (var i = 0; i < data.length; i++) {
   var rs = {
     diseaseInfo: data[i]
   }
   result[i] = {
     data: rs
   }
 }
 return result;
}