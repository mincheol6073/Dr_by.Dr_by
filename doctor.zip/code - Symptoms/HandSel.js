module.exports.function = function handSel (images) {
  return {}
}
