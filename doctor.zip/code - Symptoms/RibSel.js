module.exports.function = function ribSel (images) {
  return {}
}
