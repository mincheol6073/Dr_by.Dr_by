module.exports.function = function generateSel (images) {
  return {}
}
