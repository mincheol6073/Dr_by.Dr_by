module.exports.function = function faceSel (images) {
  return {}
}
