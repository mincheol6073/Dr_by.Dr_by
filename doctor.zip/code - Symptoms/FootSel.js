module.exports.function = function footSel (images) {
  return {}
}
