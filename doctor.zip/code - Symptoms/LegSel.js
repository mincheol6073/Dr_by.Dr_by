module.exports.function = function legSel (images) {
  return images;
}
