module.exports.function = function kidneySel (images) {
  return {}
}
