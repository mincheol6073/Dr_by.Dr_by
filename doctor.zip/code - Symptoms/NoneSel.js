module.exports.function = function noneSel (images) {
  return {}
}
