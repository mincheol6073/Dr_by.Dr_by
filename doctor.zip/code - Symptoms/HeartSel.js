module.exports.function = function heartSel (images) {
  return {}
}
