module.exports.function = function thighSel (images) {
  return images;
}
