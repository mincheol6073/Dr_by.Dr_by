module.exports.function = function select5 (symptoms, images) {
  var console = require('console');
   var partlist = symptoms.naming.split("|");
   var partset = partlist[0].split("/");
   var part = partset[2];
   var str = symptoms.naming;
   console.log(str);
   console.log(images);
   if(part!=undefined){
      for(var i = 0; i<images.length;i++){
        str += part;
        str += ":"
        str += images[i].naming;
        str += "/";
      }
   }
  return{
    naming : str,
    count : symptoms.count,
    partnum : symptoms.partnum
  }
}