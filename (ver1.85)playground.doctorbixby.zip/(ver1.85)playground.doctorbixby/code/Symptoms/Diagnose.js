module.exports.function = function diagnose(sympFin) {
 var console = require('console');
 // 윤형아 로직 짜줘
 var Data = require("data/Data.js");
 //var symp = "몸:발열/몸:피로감/머리:현기증/"
 var symptomArray = sympFin.split("/"); // 증상 split
 var resultArray = new Array();
 var keywordArray = new Array();
 for (var k = 0; k < Data.length; k++) { // 만약 data의 size가 주어질 수 있을듯? (유지보수 관점에서 json 파일의 형태를 어떻게 저장?)
   var count = 0;
   var disease = Data[k];
   var keywords = JSON.stringify(disease.keyword).split("],");

    // console.log(keywords);  

   for (var u = 0; u < keywords.length; u++) {
     keywordArray[u] = keywords[u].split(":");
   }

   for (var j = 0; j < symptomArray.length; j++) {
     var symptom = symptomArray[j].split(":");
     for (var u = 0; u < keywords.length; u++) {
       var key1 = "" + JSON.stringify(keywordArray[u][0]);
       var key2 = "" + JSON.stringify(keywordArray[u][1]);
       if (key1.includes(symptom[0]) && key2.includes(symptom[1])) {
         count++;
         break;
       }
     }
   }
   resultArray.push([disease.disease_name_kr, disease.definition, disease.detail_url, disease.img_url, count / (symptomArray.length-1)]);
 }
 resultArray.sort(function(a,b){
   return a[4]-b[4];
 });

 // 결과 담기. 수정 X
 var result = [];
 var idx = 0;
 while(resultArray.length > 0) {
   var tmp = resultArray.pop();
   var rs = {
     diseaseInfo: tmp
   }
   result[idx] = {
     data: rs
   }
   idx++;
 }
 return result;
}