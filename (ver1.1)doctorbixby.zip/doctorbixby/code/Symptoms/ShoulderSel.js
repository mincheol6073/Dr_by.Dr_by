module.exports.function = function shoulderSel (images) {
  return images;
}
