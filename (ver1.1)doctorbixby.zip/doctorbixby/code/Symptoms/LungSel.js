module.exports.function = function lungSel (images) {
  return images;
}
