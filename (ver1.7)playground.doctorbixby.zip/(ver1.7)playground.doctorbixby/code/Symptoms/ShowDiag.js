module.exports.function = function showDiag (upart,usymptom,dtarget,diag,diagResult) {
  return diagResult;
}
