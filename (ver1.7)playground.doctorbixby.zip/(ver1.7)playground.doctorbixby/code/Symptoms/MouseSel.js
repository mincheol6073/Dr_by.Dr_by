module.exports.function = function mouseSel (images) {
  return images;
}
