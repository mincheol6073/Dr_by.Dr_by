module.exports.function = function showShell2 (dtarget,diag,diagResult) {
  return diagResult;
}
