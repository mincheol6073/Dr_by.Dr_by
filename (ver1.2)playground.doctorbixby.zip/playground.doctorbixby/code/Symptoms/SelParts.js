module.exports.function = function selParts (images) {
  var console = require('console');
   var str = "";
   var cnt = images.length;
   for(var i = 0; i<images.length;i++){
     str += images[i].naming;
     if(i<images.length-1) str += "/";
   }
   var parts = str.split("/");
   var nums = [];
   for(var i=0;i<parts.length;i++){
     switch(parts[i]) {
      case "다리" : nums[i] = 1;
                   break;
      case "입" : nums[i] = 2;
                   break;
      case "배" : nums[i] = 3;
                  break;
      case "피부" : nums[i] = 4;
                  break;
      case "코" : nums[i] = 5;
                  break;
      case "머리" : nums[i] = 6;
                  break;
     }
   }
   console.log(nums);
   str += "|";
   console.log(str);
  return{
    naming : str,
    count : cnt,
    partnum : nums
  }
}
