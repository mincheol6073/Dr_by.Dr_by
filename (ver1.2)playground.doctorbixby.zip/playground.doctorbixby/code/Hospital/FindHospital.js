module.exports.function = function findHospital (point,department) {
  var console = require('console');
  
  console.log(point.latitude);
  console.log(point.longitude);
  console.log(department);
  
  var resultArray1 = [];
  var resultArray2 = [];
  // 위도 경도로 실제 거리 환산 (단위 : m)
  function deg2rad(deg){
    return deg * Math.PI / 180.0;
  }
  function rad2deg(rad){
    return rad * 180.0 / Math.PI;
  }
  function transMeter(lat1, lon1, lat2, lon2){
    var theta, dist;  
    theta = lon1 - lon2;  
    dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1))   
          * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));  
    dist = Math.acos(dist);  
    dist = rad2deg(dist);  
      
    dist = dist * 60 * 1.1515;   
    dist = dist * 1.609344;    // 단위 mile 에서 km 변환.  
    dist = dist * 1000.0;      // 단위  km 에서 m 로 변환  
  
    return dist;
  }
  // 더미데이터 테스트용
  resultArray1.push([36.350105,127.308889]);
  resultArray2.push(["한빛병원","대전광역시 유성구","010-5754-8754"]);

  resultArray1.push([36.350605,127.307589]);
  resultArray2.push(["아산병원","부산광역시 해운대구","010-5544-9712"]);

  resultArray1.push([36.350005,127.307489]);
  resultArray2.push(["삼성병원","서울특별시 강남구","010-9712-7512"]);
  // 시호 형 논리 작성


  // 결과 담기. 수정 X
  var result = [];
  var idx = 0;
  while(resultArray1.length > 0) {
    var tmp1 = resultArray1.pop();
    var tmp2 = resultArray2.pop();
    var dist = transMeter(point.latitude, point.longitude, tmp1[0], tmp1[1]);
    var locateArray = [];
    var located = {
      latitude : point.latitude,
      longitude : point.longitude
    }
    locateArray.push(located);
    located = {
      latitude : tmp1[0],
      longitude : tmp1[1]
    }
    var rs = {
      location : locateArray,
      info : tmp2,
      distance : parseInt(dist)
    }
    result[idx] = {
      data: rs
    }
    idx++;
  }
  result.sort(function(a, b) { // 오름차순
    return a.distance < b.distance ? -1 : a.distance > b.distance ? 1 : 0;
    // 광희, 명수, 재석, 형돈
  });
  return result;
}
