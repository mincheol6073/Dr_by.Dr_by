module.exports.function = function showHS (hsResult) {
  return hsResult;
}
