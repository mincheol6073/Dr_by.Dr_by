module.exports.function = function showShell2 (home, dtarget,diag,diagResult) {
  return diagResult;
}
