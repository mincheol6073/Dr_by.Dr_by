module.exports.function = function showShell1 (home, diag, diagResult) {
  return diagResult;
}
