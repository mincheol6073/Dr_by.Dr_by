module.exports.function = function skinSel (images) {
  return images;
}
