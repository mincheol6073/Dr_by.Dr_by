module.exports.function = function bladderSel (images) {
  return images;
}
