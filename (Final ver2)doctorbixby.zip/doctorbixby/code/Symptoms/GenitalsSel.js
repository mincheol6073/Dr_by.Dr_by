module.exports.function = function genitalsSel (images) {
  return images;
}
