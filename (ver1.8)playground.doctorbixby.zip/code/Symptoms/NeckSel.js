module.exports.function = function neckSel (images) {
  return images;
}
