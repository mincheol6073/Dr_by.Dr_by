module.exports.function = function backSel (images) {
  return images;
}
