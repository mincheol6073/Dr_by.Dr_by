module.exports.function = function eyeSel (images) {
  return images;
}
