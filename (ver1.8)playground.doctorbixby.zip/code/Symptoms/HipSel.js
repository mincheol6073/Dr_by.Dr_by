module.exports.function = function hipSel (images) {
  return images;
}
