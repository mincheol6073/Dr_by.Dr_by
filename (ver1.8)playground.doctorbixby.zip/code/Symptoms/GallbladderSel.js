module.exports.function = function gallbladderSel (images) {
  return images;
}
