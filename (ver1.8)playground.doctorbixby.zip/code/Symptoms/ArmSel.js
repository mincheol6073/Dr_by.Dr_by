module.exports.function = function armSel (images) {
  return images;
}
