module.exports.function = function findHospital (point,department) {
  const config = require('config');
  const http = require('http');
  const fail = require('fail');
  const kakaoLocalAPI = config.get('kakaoLocalAPIURL');
  const APIKey = config.get('kakaoAPIKey');
  var console = require('console');
  
  let api_key = APIKey;
  let url = kakaoLocalAPI;
  console.debug(api_key);
  console.debug(url);
  console.debug(point.latitude);
  console.debug(point.longitude);
  console.debug(department);
  
  var options = {
    format : 'json',
    headers : {
      'Authorization' : api_key
    },
    query :{
      query : department,
      x : point.longitude,
      y : point.latitude,
      radius : 5000,
      sort : 'distance'
    }
  }

  let response = http.getUrl(url, options);

  if(response.status == 404 || response.status == 500 || response.status == 502 || response.status == 504){ 
    throw fail.checkedError("Server Error", "ServerProblem"); 
  }

  

  let datas = response.documents;


  //console.debug("res", datas);
  
  // 위도 경도로 실제 거리 환산 (단위 : m)
  // function deg2rad(deg){
  //   return deg * Math.PI / 180.0;
  // }
  // function rad2deg(rad){
  //   return rad * 180.0 / Math.PI;
  // }
  // function transMeter(lat1, lon1, lat2, lon2){
  //   var theta, dist;  
  //   theta = lon1 - lon2;  
  //   dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1))   
  //         * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));  
  //   dist = Math.acos(dist);  
  //   dist = rad2deg(dist);  
      
  //   dist = dist * 60 * 1.1515;   
  //   dist = dist * 1.609344;    // 단위 mile 에서 km 변환.  
  //   dist = dist * 1000.0;      // 단위  km 에서 m 로 변환  
  
  //   return dist;
  // }
  // 더미데이터 테스트용
  // resultArray.push(["36.350105","127.308889","한빛병원","대전광역시 유성구","010-5754-8754","123"]);
  // resultArray.push(["36.350605","127.307589","아산병원","부산광역시 해운대구","010-5544-9712","134"]);
  // resultArray.push(["36.350005","127.307489","삼성병원","서울특별시 강남구","010-9712-7512","165"]);
  
  
  // [0] latitude [1] longitude [2] 병원 명 [3] 주소 [4] 연락처 [5] 거리
  var resultArray = []; 
  // 시호 형 논리 작성

  for(var i = 0; i < datas.length; i++){
    var latitude = datas[i].y;
    var longitude = datas[i].x;
    var place_name = datas[i].place_name;
    var address_name = datas[i].address_name;
    var phone = datas[i].phone;
    var distance = datas[i].distance;
    resultArray.push([latitude, longitude, place_name, address_name, phone, distance]);
  }

//   address_name:서울 중구 태평로1가 31-25
// category_group_code:
// category_group_name:
// category_name:의료,건강 > 병원 > 한방병원 > 한의원
// distance:
// id:14822822
// phone:02-734-1075
// place_name:덕수한의원
// place_url:http://place.map.kakao.com/14822822
// road_address_name:서울 중구 세종대로20길 19
// x:126.97845634937015 longitude
// y:37.56713591165745 latitude




  // 결과 담기. 수정 X
  var result = [];
  for(var i=0;i<resultArray.length;i++){
    var tmp = [];
    tmp.push(resultArray[i][2],resultArray[i][3],resultArray[i][4]);
    var locateArray = [];
    var located = {
      latitude : point.latitude,
      longitude : point.longitude
    }
    locateArray.push(located);
    located = {
      latitude : parseFloat(resultArray[i][0]),
      longitude : parseFloat(resultArray[i][1])
    }
    locateArray.push(located);
    var rs = {
      location : locateArray,
      info : tmp,
      distance : parseInt(resultArray[i][5])
    }
    result[i] = {
      data: rs
    }
  }
  // result.sort(function(a, b) { // 오름차순
  //   return a.distance < b.distance ? -1 : a.distance > b.distance ? 1 : 0;
  //   // 광희, 명수, 재석, 형돈
  // });
  return result;
}
