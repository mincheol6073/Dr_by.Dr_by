module.exports.function = function showDiag (diagResult) {
  return diagResult;
}
