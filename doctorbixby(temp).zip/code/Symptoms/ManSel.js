module.exports.function = function manSel (images) {
  return images;
}
