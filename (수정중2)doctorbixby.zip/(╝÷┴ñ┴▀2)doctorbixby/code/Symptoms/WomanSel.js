module.exports.function = function womanSel (images) {
  return images;
}
