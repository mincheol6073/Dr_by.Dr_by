module.exports.function = function mentalSel (images) {
  return images;
}
