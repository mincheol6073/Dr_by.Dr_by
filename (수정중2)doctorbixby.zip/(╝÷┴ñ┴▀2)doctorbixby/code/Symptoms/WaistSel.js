module.exports.function = function waistSel (images) {
  return images;
}
