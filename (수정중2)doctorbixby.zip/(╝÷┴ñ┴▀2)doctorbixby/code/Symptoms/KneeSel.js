module.exports.function = function kneeSel (images) {
  return images;
}
